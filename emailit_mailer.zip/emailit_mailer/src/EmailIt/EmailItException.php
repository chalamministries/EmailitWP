<?php

namespace EmailIt;

class EmailItException extends \Exception {}